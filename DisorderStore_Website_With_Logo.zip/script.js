
document.getElementById("topupForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const userId = document.getElementById("userId").value;
  const zoneId = document.getElementById("zoneId").value;
  const nominal = document.getElementById("nominal").value;
  const payment = document.getElementById("payment").value;

  const message = `Halo Admin DisorderStore%0ASaya ingin top up Mobile Legends:%0A- User ID: ${userId}%0A- Zone ID: ${zoneId}%0A- Diamond: ${nominal}%0A- Pembayaran: ${payment}`;

  const whatsappNumber = "6281234567890"; // Ganti dengan nomor admin
  const waLink = `https://wa.me/${whatsappNumber}?text=${message}`;

  window.open(waLink, "_blank");
});
